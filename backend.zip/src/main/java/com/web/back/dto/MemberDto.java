package com.web.back.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class MemberDto {
    private Long id;
    private String number;
    private String password;
    private String newPassword;
    private String passwordCheck;
    private String newPasswordCheck;
    private String email;
    private String name;
    private Integer identity;

    public MemberDto setFormat() {
        return new MemberDto();
    }

}
