package com.web.back.dto;

import com.web.back.model.Problem;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class ProblemDto {
    private Long id;
    private int number;
    private String title;
    private String descripsion;
    private Integer language;
    private LocalDateTime upload_time;
    private Long uploader_id;
    private String uploader;

    public ProblemDto() {

    }

    public ProblemDto(Long id, String title, String descripsion, Integer language, LocalDateTime upload_time, Long uploader_id, String uploader) {
        this.id = id;
        this.title = title;
        this.descripsion = descripsion;
        this.language = language;
        this.upload_time = upload_time;
        this.uploader_id = uploader_id;
        this.uploader = uploader;
    }

    public static ProblemDto setFormat(Problem problem) {
        ProblemDto problemDto = new ProblemDto(
                problem.getId(),
                problem.getTitle(),
                problem.getDescripsion(),
                problem.getLanguage(),
                problem.getUpload_time(),
                problem.getUp_member().getId(),
                problem.getUp_member().getName()
        );

        return problemDto;
    }

    public static ProblemDto setFormat(Problem problem, int number) {
        ProblemDto problemDto = new ProblemDto(
                problem.getId(),
                problem.getTitle(),
                problem.getDescripsion(),
                problem.getLanguage(),
                problem.getUpload_time(),
                problem.getUp_member().getId(),
                problem.getUp_member().getName()
        );
        problemDto.setNumber(number);
        return problemDto;
    }
}
