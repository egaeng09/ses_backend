package com.web.back.utils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class CompileManager {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    String inputFilePath;
    String outputFilePath;

    //output 테스트케이스와 실행결과를 비교
    public String compareCodeWithTestCase(String executedCodeOutput, String testCaseOutput) {
        String comparisonResult;
        if (executedCodeOutput.trim().equals(testCaseOutput.trim())) {
            comparisonResult = "****** 정답입니다! ******  ";
        } else {
            comparisonResult = "****** 오답입니다 ㅜㅡㅜ ****** ";
        }
        return comparisonResult;
    }

    //System.in --> convert
    public String convertCode(String code){
        return code.replaceAll("System\\.in", "args[0]");
    }


    //테스트케이스 읽어오기
    public StringBuilder readNumbersFromFile(String filePath) {
        StringBuilder code = new StringBuilder();
        try {
            File file = new File(filePath);
            Scanner scanner = new Scanner(file, StandardCharsets.UTF_8.name());

            while (scanner.hasNext()) {
                if (scanner.hasNextInt()) {
                    int number = scanner.nextInt();
                    code.append(number).append(" "); // 숫자를 문자열로 변환하여 code에 추가
                } else {
                    // 숫자가 아닌 경우 다음 토큰으로 이동
                    scanner.next();
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return code;
    }
    //테스트케이스 입력 또는 추가
    public void inputTestCase() {
        try {
            System.out.println("TestCase 이름을 입력해주세요:");
            String testcaseName = reader.readLine();

            System.out.print("Input: ");
            String testcaseInput = reader.readLine();

            String directoryPath = "/Users/jeonghwan-il/Desktop/TestCase/";
//            String directoryPath = "/Users/Home/Desktop/SES/Testcase/";
            inputFilePath = directoryPath + testcaseName + "-Input.txt";  // inputFilePath에 값을 할당
            outputFilePath = directoryPath + testcaseName + "-Output.txt";

            try (BufferedWriter inputWriter = new BufferedWriter(new FileWriter(inputFilePath));
                 BufferedWriter outputWriter = new BufferedWriter(new FileWriter(outputFilePath))) {
                inputWriter.write(testcaseInput);

                System.out.print("Output: ");
                String testcaseOutput = reader.readLine();
                outputWriter.write(testcaseOutput);

                System.out.println("Test case input and output have been saved.");
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("파일 쓰기 오류가 발생했습니다: " + e.getMessage());
            }

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("입력 오류가 발생했습니다: " + e.getMessage());
        }
    }

    ////기존 테스트케이스를 사용할때 컴파일 및 실행
//    public String compileJava() {
//        StringBuilder output = new StringBuilder();
//
//        Thread compilationThread = new Thread(() -> {
//            try {
//                // 코드를 입력받을 BufferedReader
//                BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//                StringBuilder code = new StringBuilder();
//                Scanner s= new Scanner(System.in);
//
//                System.out.print("class 이름을 작성하세요 : ");
//                String fileName = reader.readLine(); // 파일 이름에서 확장자 .java는 제외합니다.
//
//                System.out.println("코드를 입력하세요 (입력이 끝나면 'done'을 입력하세요):");
//                code.append("import java.io.*;\n");
//                code.append("import java.util.*;\n");
//                code.append("public class " + fileName + "{\n");
//                code.append("    public static void main(String[] args) {\n");
//
////              String inputFilePath = testCaseManager.getInputFilePath();
////              StringBuilder sourceBuilder = readNumbersFromFile(inputFilePath);
//
//                StringBuilder sourceBuilder = readNumbersFromFile("/Users/jeonghwan-il/Desktop/add1.txt");
////                StringBuilder sourceBuilder = readNumbersFromFile("/Users/Home/Desktop/SES/add1.txt");
//                String source = sourceBuilder.toString();
//                code.append("\tString source = \"" + source + "\";\n");
//
//                System.out.println(code);
//                // 사용자로부터 코드 입력 받기 (입력이 끝날 때까지 계속 입력 받음)
//                String line;
//                while (!(line = reader.readLine()).equalsIgnoreCase("done")) {
//
//                    code.append(line).append("\n");
//                }
//
//                code.append("    }\n");
//                code.append("}\n");
//
//                String convertedCode = convertCode(code);
//
//                // 입력한 코드를 파일로 저장
////                String filePath = "/Users/jeonghwan-il/Desktop/" + fileName + ".java";
//                String filePath = "/Users/Home/Desktop/SES/" + fileName + ".java";
//                try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
//                    writer.write(convertedCode);
//                }
//
//                // 저장한 파일을 컴파일 및 실행
//                String compileCommand = "javac " + filePath;
//                Process compileProcess = Runtime.getRuntime().exec(compileCommand);
//                compileProcess.waitFor();
//                compileProcess.destroy();
//
//
//                String runCommand = "java -classpath /Users/jeonghwan-il/Desktop " + fileName;
////                String runCommand = "java -classpath /Users/Home/Desktop/SES " + fileName;
//                Process runProcess = new ProcessBuilder("bash", "-c", runCommand).redirectErrorStream(true).start();
//
//
//
//                try (BufferedReader br = new BufferedReader(new InputStreamReader(runProcess.getInputStream()))) {
//                    String resultLine;
//                    while ((resultLine = br.readLine()) != null) {
//                        output.append(resultLine).append("\n");
//                    }
//                }
//
//                // 프로세스의 종료를 기다립니다.
//                runProcess.waitFor();
//
//
//                StringBuilder testCaseOutputBuilder = readNumbersFromFile("/Users/jeonghwan-il/Desktop/add-out.txt");
////                StringBuilder testCaseOutputBuilder = readNumbersFromFile("/Users/Home/Desktop/SES/add-out.txt");
//                String testCaseOutput = testCaseOutputBuilder.toString();
//
//                String comparisonResult = compareCodeWithTestCase(output.toString(), testCaseOutput);
//                System.out.println(comparisonResult);
//
//
//
//            } catch (IOException | InterruptedException e) {
//                output.append(e.toString()).append("\n");
//            }
//        });
//
//        compilationThread.start();
//
//        try {
//            compilationThread.join(); // 스레드의 종료를 기다립니다.
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//
//        // 결과를 문자열로 반환
//        return output.toString();
//    }


    //테스트케이스 입력했을 경우 컴파일 및 실행
//    public String testPlusCompileJava() {
//        StringBuilder output = new StringBuilder();
//
//        Thread compilationThread = new Thread(() -> {
//            try {
//                //TestCaseManager testCase = new TestCaseManager();
//                // 코드를 입력받을 BufferedReader
//                BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//                StringBuilder code = new StringBuilder();
//                Scanner s= new Scanner(System.in);
//
//                System.out.print("class 이름을 작성하세요 : ");
//                String fileName = reader.readLine(); // 파일 이름에서 확장자 .java는 제외합니다.
//
//                System.out.println("코드를 입력하세요 (입력이 끝나면 'done'을 입력하세요):");
//                code.append("import java.io.*;\n");
//                code.append("import java.util.*;\n");
//                code.append("public class " + fileName + "{\n");
//                code.append("    public static void main(String[] args) {\n");
//
//
//                String inputFile = inputFilePath; // 여기서 inputFilePath 값을 가져오고 있는지 확인
//                StringBuilder sourceBuilder = readNumbersFromFile(inputFile);
//
////              StringBuilder sourceBuilder = readNumbersFromFile("/Users/jeonghwan-il/Desktop/add1.txt");
//                String source = sourceBuilder.toString();
//                code.append("\tString source = \"" + source + "\";\n");
//
//                System.out.println(code);
//                // 사용자로부터 코드 입력 받기 (입력이 끝날 때까지 계속 입력 받음)
//                String line;
//                while (!(line = reader.readLine()).equalsIgnoreCase("done")) {
//
//                    code.append(line).append("\n");
//                }
//
//                code.append("    }\n");
//                code.append("}\n");
//
//                String convertedCode = convertCode(code);
//
//                // 입력한 코드를 파일로 저장
//                String filePath = "/Users/jeonghwan-il/Desktop/" + fileName + ".java";
////                String filePath = "/Users/Home/Desktop/SES/" + fileName + ".java";
//                try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
//                    writer.write(convertedCode);
//                }
//
//                // 저장한 파일을 컴파일 및 실행
//                String compileCommand = "javac " + filePath;
//                Process compileProcess = Runtime.getRuntime().exec(compileCommand);
//                compileProcess.waitFor();
//                compileProcess.destroy();
//
//
//                String runCommand = "java -classpath /Users/jeonghwan-il/Desktop " + fileName;
////                String runCommand = "java -classpath /Users/Home/Desktop/SES/ " + fileName;
//                Process runProcess = new ProcessBuilder("bash", "-c", runCommand).redirectErrorStream(true).start();
//
//                try (BufferedReader br = new BufferedReader(new InputStreamReader(runProcess.getInputStream()))) {
//                    String resultLine;
//                    while ((resultLine = br.readLine()) != null) {
//                        output.append(resultLine).append("\n");
//                    }
//                }
//                // 프로세스의 종료를 기다립니다.
//                runProcess.waitFor();
//
//                StringBuilder testCaseOutputBuilder = readNumbersFromFile(outputFilePath);
//                String testCaseOutput = testCaseOutputBuilder.toString();
//
//                String comparisonResult = compareCodeWithTestCase(output.toString(), testCaseOutput);
//                System.out.println(comparisonResult);
//
//            } catch (IOException | InterruptedException e) {
//                output.append(e.toString()).append("\n");
//            }
//        });
//
//        compilationThread.start();
//
//        try {
//            compilationThread.join(); // 스레드의 종료를 기다립니다.
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // 결과를 문자열로 반환
//        return output.toString();
//    }

    public String backCompile(String inputCode, String inputTestcase) {
        StringBuilder output = new StringBuilder();

        try {
            // 클래스 이름을 임의로 지정 (원하는 로직에 따라 변경 가능)
            String fileName = "Main";

            String convertedCode = convertCode(inputCode);

            // 코드를 파일로 저장하지 않고 바로 컴파일 및 실행
//            String filePath = "/Users/jeonghwan-il/Desktop/" + fileName + ".java";
            String filePath = "C:\\Users\\KWON\\Desktop\\" + fileName + ".java";
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
                writer.write(convertedCode);
            }

            // 저장한 파일을 컴파일 및 실행
//            String compileCommand = "javac " + filePath;
            String compileCommand = "javac -source 1.8 -target 1.8 " + filePath;
            Process compileProcess = Runtime.getRuntime().exec(compileCommand);
            compileProcess.waitFor();
            compileProcess.destroy();

//            String runCommand = "java -classpath /Users/jeonghwan-il/Desktop " + fileName + " \"" + inputTestcase + "\"";
            String runCommand = "java -classpath C:\\Users\\KWON\\Desktop " + fileName + " \"" + inputTestcase + "\"";

//            Process runProcess = new ProcessBuilder("bash", "-c", runCommand).redirectErrorStream(true).start();
                Process runProcess = new ProcessBuilder("cmd.exe", "/c", runCommand).redirectErrorStream(true).start();

            try (BufferedReader br = new BufferedReader(new InputStreamReader(runProcess.getInputStream()))) {
                String resultLine;
                while ((resultLine = br.readLine()) != null) {
                    output.append(resultLine).append("\n");
                }
            }

            // 프로세스의 종료를 기다립니다.
            runProcess.waitFor();
            File f = new File("C:\\Users\\KWON\\Desktop\\" + fileName + ".java");
            f.delete();
            File f2 = new File("C:\\Users\\KWON\\Desktop\\" + fileName + ".class");
            f2.delete();
        } catch (IOException | InterruptedException e) {
            output.append(e.toString()).append("\n");
        }

        // 결과를 문자열로 반환
        return output.toString();
    }
}
