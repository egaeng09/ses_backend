package com.web.back.repository;

import com.web.back.model.Lesson;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LessonRepository  extends JpaRepository<Lesson, Long> {
    List<Lesson> findAllByMemberId(Long ownerId);

    @Query(value = "SELECT l FROM Lesson l WHERE l.name LIKE %:keyword%")
    List<Lesson> findAllSearch(String keyword);

}
