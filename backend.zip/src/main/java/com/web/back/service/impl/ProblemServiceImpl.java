package com.web.back.service.impl;

import com.web.back.dto.SearchDataDto;
import com.web.back.dto.SubmitDto;
import com.web.back.dto.TestcaseDto;
import com.web.back.model.*;
import com.web.back.dto.ProblemDto;
import com.web.back.repository.MemberRepository;
import com.web.back.repository.ProblemRepository;
import com.web.back.repository.SubmitRepository;
import com.web.back.repository.TestcaseRepository;
import com.web.back.service.AccountService;
import com.web.back.service.ProblemService;
import com.web.back.utils.CompileManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProblemServiceImpl implements ProblemService {

    @Autowired
    private ProblemRepository problemRepository;

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private TestcaseRepository testcaseRepository;

    @Autowired
    private SubmitRepository submitRepository;

    @Autowired
    private AccountService accountService;

    // 문제 목록 조회
    @Override
    public List<ProblemDto> getProblemList() throws Exception {
        List<Problem> problems = problemRepository.findAll();
        List<ProblemDto> problemDtos = new ArrayList<>();
        problems.forEach(s -> problemDtos.add(ProblemDto.setFormat(s, problems.indexOf(s) + 1)));

        return problemDtos;
    }

    // 문제 상세 정보 조회
    @Override
    public ProblemDto getProblemDetail(Long problemId) throws Exception {
        Problem problem = problemRepository.findById(problemId).orElseThrow(() -> {
            return new IllegalArgumentException("해당 문제를 찾을 수 없습니다.");
        });

//        if (problemRepository.findHaveTestcase(problemId).isEmpty()) {
//            throw new IllegalArgumentException("테스트 케이스가 등록되지 않았습니다.");
//        }

        ProblemDto problemDto = ProblemDto.setFormat(problem);

        return problemDto;
    }

    // 문제 등록
    @Override
    public ProblemDto registerProblem(ProblemDto problemDto) throws Exception {
        Problem problem = new Problem();
        problem.setTitle(problemDto.getTitle());
        problem.setDescripsion(problemDto.getDescripsion());
        problem.setUpload_time(LocalDateTime.now());
        problem.setLanguage(problemDto.getLanguage());

        Member member = accountService.getAuthenticatedMember();
        problem.setUp_member(member);

        problemRepository.save(problem);

        return ProblemDto.setFormat(problem);
    }

    // 문제 수정
    @Override
    public ProblemDto editProblem(Long problemId, ProblemDto problemDto) throws Exception {
        Problem problem = problemRepository.findById(problemId).orElseThrow(() -> {
            return new IllegalArgumentException("해당 문제를 찾을 수 없습니다.");
        });

        // 문제 등록자와 동일한지 검증
        /* */

        problem.setTitle(problemDto.getTitle());
        problem.setDescripsion(problemDto.getDescripsion());
        problem.setUpload_time(LocalDateTime.now());
        problem.setLanguage(problemDto.getLanguage());

        problemRepository.save(problem);

        return ProblemDto.setFormat(problem);
    }

    // 문제 삭제
    @Override
    public void deleteProblem(Long problemId) throws Exception {
        Problem problem = problemRepository.findById(problemId).orElseThrow(() -> {
            return new IllegalArgumentException("해당 문제를 찾을 수 없습니다.");
        });

        // 문제 등록자와 동일한지 검증
        /* */

        problemRepository.deleteById(problemId);
    }

    // 문제 검색 (제목 / 내용)
    @Override
    public List<ProblemDto> searchProblem(String keyword) throws Exception {
        List<Problem> problems = problemRepository.findAllSearch(keyword);
        List<ProblemDto> problemDtos = new ArrayList<>();
        problems.forEach(s -> problemDtos.add(ProblemDto.setFormat(s, problems.indexOf(s) + 1)));

        return problemDtos;
    }

    // 문제 코드 실행
    @Override
    public SubmitDto runProblemCode(Long problemId, SubmitDto submitDto) throws Exception {
        CompileManager compile = new CompileManager();

        Problem problem = problemRepository.findById(problemId).orElseThrow(() -> {
            return new IllegalArgumentException("해당 문제를 찾을 수 없습니다.");
        });

        List<Testcase> testCases = testcaseRepository.findByProblemId(problem.getId());

        Integer score = 0 ;
        String result = "";

        for (Testcase testCase : testCases) {

            String codeOutput = compile.backCompile(submitDto.getSubmit_contents(),testCase.getInput());
            String expectedOutput = testCase.getOutput();

            //System.out.println(testCase.getInput() + "/" + testCase.getOutput());

            boolean isTestCasePassed = codeOutput.trim().equals(expectedOutput.trim());
            // 조건 하나 더 주고
            // 컴파일 에러입니다. 추가하기 throw로 예외 던지고 코드 중지해주는 기능 추가하기

            System.out.println(codeOutput.trim());
            System.out.println(expectedOutput.trim());

            if( isTestCasePassed ==true)
            {
                result = "정답입니다.";
                score = 100;

            }
            else
            {
                result = "오답입니다.";
                score = 0;
                break;
            }
        }

        submitDto.setSubmit_time(LocalDateTime.now());
        submitDto.setScore(score);
        submitDto.setResult(result);

        return submitDto;
    }

    // 문제 풀이 제출
    @Override
    public SubmitDto submitProblemCode(Long problemId, SubmitDto submitDto) throws Exception {

        SubmitDto newSubmit = runProblemCode(problemId, submitDto);
        Submit submit = new Submit();

        Member member = accountService.getAuthenticatedMember();
        submit.setMember(member);

        submit.setResult(newSubmit.getResult());
        submit.setScore(newSubmit.getScore());
        submit.setProblem(problemRepository.findById(newSubmit.getProblem_id()).orElseThrow(() -> {
            return new IllegalArgumentException("해당 문제를 찾을 수 없습니다.");
        }));

        submit.setSubmit_contents(newSubmit.getSubmit_contents());
        submit.setSubmit_time(newSubmit.getSubmit_time());

        submitRepository.save(submit);

        return SubmitDto.setFormat(submit);
    }

    // 문제 테스트케이스 등록
    @Override
    public TestcaseDto addProblemTestcase(TestcaseDto testcaseDto) throws  Exception {
        Problem problem = problemRepository.findById(testcaseDto.getProblem_id()).orElseThrow(() -> {
            return new IllegalArgumentException("해당 문제를 찾을 수 없습니다.");
        });

        Testcase testcase = new Testcase();
        testcase.setInput(testcaseDto.getInput());
        testcase.setOutput(testcaseDto.getOutput());
        testcase.setProblem(problem);
        testcaseRepository.save(testcase);
        return TestcaseDto.setFormat(testcase);
    }

    // 문제 테스트케이스 수정
    @Override
    public TestcaseDto editProblemTestcase(Long testcaseId, TestcaseDto testcaseDto) throws  Exception {
        Testcase testcase = testcaseRepository.findById(testcaseId).orElseThrow(() -> {
            return new IllegalArgumentException("해당 테스트 케이스를 찾을 수 없습니다.");
        });
        testcase.setInput(testcaseDto.getInput());
        testcase.setOutput(testcaseDto.getOutput());
        testcaseRepository.save(testcase);
        return TestcaseDto.setFormat(testcase);
    }

    // 문제 테스트케이스 삭제
    @Override
    public void deleteProblemTestcase(Long testcaseId) throws Exception {
        Testcase testcase = testcaseRepository.findById(testcaseId).orElseThrow(() -> {
            return new IllegalArgumentException("해당 테스트 케이스를 찾을 수 없습니다.");
        });
        testcaseRepository.delete(testcase);
    }

    // 문제 테스트케이스 조회
    @Override
    public List<TestcaseDto> getProblemTestcaseList(Long problemId) throws  Exception {
        List<Testcase> testcases = testcaseRepository.findByProblemId(problemId);
        List<TestcaseDto> testcaseDtos = new ArrayList<>();
        testcases.forEach(s -> testcaseDtos.add(TestcaseDto.setFormat(s)));

        return testcaseDtos;
    }

}
