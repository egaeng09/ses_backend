package com.web.back.service.impl;

import com.web.back.repository.MemberRepository;
import com.web.back.service.ManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ManagementServiceImpl implements ManagementService {

    @Autowired
    private MemberRepository memberRepository;

}
