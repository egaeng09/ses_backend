package com.web.back.service.impl;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.web.back.dto.*;
import com.web.back.model.*;
import com.web.back.repository.*;
import com.web.back.service.AccountService;
import com.web.back.service.AssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class AssignmentServiceImpl implements AssignmentService {

    @Autowired
    private AssignmentRepository assignmentRepository;
    @Autowired
    private SubmitRepository submitRepository;
    @Autowired
    private MemberRepository memberRepository;
    @Autowired
    private LessonRepository lessonRepository;
    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private TestcaseRepository testcaseRepository;

    @Autowired
    private AccountService accountService;

    // 과제 목록 조회
    @Override
    public List<AssignmentDto> getAssignmentList(Long lessonId) throws Exception {
        List<Assignment> assignments = assignmentRepository.findAllByLessonId(lessonId);
        List<AssignmentDto> assignmentDtos = new ArrayList<>();
        assignments.forEach(s -> assignmentDtos.add(AssignmentDto.setFormat(s, assignments.indexOf(s) + 1)));

        return assignmentDtos;
    }

    // 과제 상세 조회
    @Override
    public AssignmentDto getAssignmentDetail(Long assignmentId) throws Exception {
        Assignment assignment = assignmentRepository.findById(assignmentId).orElseThrow(() -> {
            return new IllegalArgumentException("해당 강의실을 찾을 수 없습니다.");
        });

        AssignmentDto assignmentDto = AssignmentDto.setFormat(assignment);
        return assignmentDto;
    }

    // 과제 등록
    @Override
    public AssignmentDto addAssignment(AssignmentDto assignmentDto) throws Exception {
        Assignment assignment = new Assignment();
        assignment.setTitle(assignmentDto.getTitle());
        assignment.setDescripsion(assignmentDto.getDescripsion());
        assignment.setStart_time(LocalDateTime.now());
//        assignment.setStart_time(assignmentDto.getStart_time());
        assignment.setEnd_time(assignmentDto.getEnd_time());
        assignment.setLanguage(assignmentDto.getLanguage());

        assignment.setLesson(lessonRepository.findById(assignmentDto.getLessonId()).orElseThrow(() -> {
            return new IllegalArgumentException("해당 강의실을 찾을 수 없습니다.");
        }));

        assignmentRepository.save(assignment);

        return AssignmentDto.setFormat(assignment);
    }

    // 과제 수정
    @Override
    public AssignmentDto editAssignment(Long assId, AssignmentDto assignmentDto) throws Exception {
        Assignment assignment = assignmentRepository.findById(assId).orElseThrow(() -> {
            return new IllegalArgumentException("해당 문제를 찾을 수 없습니다.");
        });
        assignment.setTitle(assignmentDto.getTitle());
        assignment.setDescripsion(assignmentDto.getDescripsion());
//        assignment.setStart_time(assignmentDto.getStart_time());
        assignment.setEnd_time(assignmentDto.getEnd_time());
        assignment.setLanguage(assignmentDto.getLanguage());
        // 나중에 수정
//        assignment.setLesson(lessonRepository.findById(assignmentDto.getLessonId()).orElseThrow(() -> {
//            return new IllegalArgumentException("해당 강의실을 찾을 수 없습니다.");
//        }));

        assignmentRepository.save(assignment);

        return AssignmentDto.setFormat(assignment);
    }

    // 과제 삭제
    @Override
    public void deleteAssignment(Long assId) throws Exception {
        Assignment assignment = assignmentRepository.findById(assId).orElseThrow(() -> {
            return new IllegalArgumentException("해당 문제를 찾을 수 없습니다.");
        });
        assignmentRepository.delete(assignment);
    }

    // 과제 코드 실행
    @Override
    public SubmitDto runAssignmentCode(Long assignmentId, SubmitDto submitDto) throws Exception {

        return submitDto;
    }

    // 과제 코드 제출
    @Override
    public SubmitDto submitAssignmentCode(Long assignmentId, SubmitDto submitDto) throws Exception {
        // 지금 날짜랑 마감일 비교해서 마감일 지났으면 제출 못하게 예외 throw
        return submitDto;
    }

    // 멤버별 과제 채점 결과 조회
    @Override
    public List<SubmitDto> getMyAssignmentScoreList(Long assignmentId, Long memberId) throws Exception {
        List<Submit> submits = submitRepository.findAllByAssignmentIdAndMemberId(memberId, assignmentId);
        List<SubmitDto> submitDtos = new ArrayList<>();
        submits.forEach(s -> submitDtos.add(SubmitDto.setFormat(s)));

        return submitDtos;
    }

    // 과제별 채점 결과 조회
    @Override
    public List<SubmitDto> getAssignmentScoreList(Long assId) throws Exception {
        List<Submit> submits = submitRepository.findAllByAssignmentId(assId);
        List<SubmitDto> submitDtos = new ArrayList<>();
        submits.forEach(s -> submitDtos.add(SubmitDto.setFormat(s)));

        return submitDtos;
    }

    // 과제 채점 결과 상세 조회
    @Override
    public SubmitDto getAssignmentScoreDetail(Long submitId) throws Exception {
        Submit submit = submitRepository.findById(submitId).orElseThrow();

        return SubmitDto.setFormat(submit);
    }

    // 과제 채점 결과 수정
    @Override
    public SubmitDto editAssignmentScoreDetail(Long submitId, SubmitDto submitDto) throws Exception {
        Submit submit = submitRepository.findById(submitId).orElseThrow();
        submit.setScore(submitDto.getScore());
        submitRepository.save(submit);

        return SubmitDto.setFormat(submit);
    }

    // 과제 테스트케이스 등록
    @Override
    public TestcaseDto addAssignmentTestcase(TestcaseDto testcaseDto) throws  Exception {
        Assignment assignment = assignmentRepository.findById(testcaseDto.getAssignment_id()).orElseThrow(() -> {
            return new IllegalArgumentException("해당 과제를 찾을 수 없습니다.");
        });

        Testcase testcase = new Testcase();
        testcase.setInput(testcaseDto.getInput());
        testcase.setOutput(testcaseDto.getOutput());
        testcase.setAssignment(assignment);
        testcaseRepository.save(testcase);
        return TestcaseDto.setFormat(testcase);
    }

    // 과제 테스트케이스 수정
    @Override
    public TestcaseDto editAssignmentTestcase(Long testcaseId, TestcaseDto testcaseDto) throws  Exception {
        Testcase testcase = testcaseRepository.findById(testcaseId).orElseThrow(() -> {
            return new IllegalArgumentException("해당 테스트 케이스를 찾을 수 없습니다.");
        });
        testcase.setInput(testcaseDto.getInput());
        testcase.setOutput(testcaseDto.getOutput());
        testcaseRepository.save(testcase);
        return TestcaseDto.setFormat(testcase);
    }

    // 과제 테스트케이스 삭제
    @Override
    public void deleteAssignmentTestcase(Long testcaseId) throws Exception {
        Testcase testcase = testcaseRepository.findById(testcaseId).orElseThrow(() -> {
            return new IllegalArgumentException("해당 테스트 케이스를 찾을 수 없습니다.");
        });
        testcaseRepository.delete(testcase);
    }

    // 과제 테스트케이스 조회
    @Override
    public List<TestcaseDto> getAssignmentTestcaseList(Long problemId) throws  Exception {
        List<Testcase> testcases = testcaseRepository.findByProblemId(problemId);
        List<TestcaseDto> testcaseDtos = new ArrayList<>();
        testcases.forEach(s -> testcaseDtos.add(TestcaseDto.setFormat(s)));

        return testcaseDtos;
    }
}
