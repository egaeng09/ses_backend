package com.web.back.service;

import com.web.back.dto.MemberDto;
import com.web.back.model.Member;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface AccountService extends UserDetailsService{
    MemberDto signUp(MemberDto memberDto) throws Exception;

    MemberDto changePassword(MemberDto memberDto)
            throws Exception;

    void deleteAccount() throws Exception;

    Member getAuthenticatedMember() throws Exception;

    MemberDto convertUserToResponseDto(Member member);
}