package com.web.back.service.impl;

import java.util.Optional;

import com.web.back.dto.MemberDto;
import com.web.back.model.Member;
import com.web.back.repository.MemberRepository;
import com.web.back.service.AccountService;
import com.web.back.utils.validation.AccountValidation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl implements AccountService {
    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AccountValidation accountValidation;


    @Override
    public MemberDto signUp(MemberDto memberDto) throws Exception {
        // 이메일과 학번 중복 체크
        final String password = memberDto.getPassword();
        final String email = memberDto.getEmail();
//        final Long id = memberDto.getId();
        final String number = memberDto.getNumber();

        accountValidation.validateSignUp(memberDto);

        if (memberRepository.existsByEmail(email)) {
            throw new Exception("가입된 이메일이 존재합니다.");
        }
        if (memberRepository.existsByNumber(number)) {
            throw new Exception("가입된 학번이 존재합니다");
        }

        Member member = new Member();
        member.setEmail(email);
//        member.setId(id); // id = AI
        member.setPassword(passwordEncoder.encode(password));
        member.setNumber(number);
        // 교수 학번에 따른 회원가입 구분 필요...
        member.setIdentity(1);

        memberRepository.save(member);
        return convertUserToResponseDto(member);
    }

    @Override
    public MemberDto changePassword(MemberDto memberDto) throws Exception {
        final String password = memberDto.getPassword();
        final String newPassword = memberDto.getNewPassword();
        accountValidation.validateChangePassword(memberDto);
        Member authenticatedMember = getAuthenticatedMember();
        // 비밀번호 확인
        if (!passwordEncoder.matches(password, authenticatedMember.getPassword())) {
            throw new Exception("The password is not correct.");
        }
        authenticatedMember.setPassword(passwordEncoder.encode(newPassword));// encode: 클라이언트에서 암호화하고 서버에선 복호화하지 않기(단방향 암호화)
        memberRepository.save(authenticatedMember);
        return convertUserToResponseDto(authenticatedMember);
    }

    @Override
    public void deleteAccount() throws Exception {
        Member authenticatedMember = getAuthenticatedMember();
        memberRepository.delete(authenticatedMember);
        if (memberRepository.findById(authenticatedMember.getId()).isPresent()) {
            throw new Exception("An error occured when deleting your account.");
        }
    }

    @Override
    public MemberDto convertUserToResponseDto(Member member) {
        MemberDto memberDto = new MemberDto();
        memberDto.setId(member.getId());
        memberDto.setName(member.getName());
        memberDto.setEmail(member.getEmail());
        return memberDto;
    }

    @Override
    public UserDetails loadUserByUsername(String id) throws UsernameNotFoundException {
        Optional<Member> userOptional = memberRepository.findByNumber(id);
        if (!userOptional.isPresent()) {
            throw new UsernameNotFoundException(String.format("The user info or password is not correct: '%s'.", id));
        }
        return userOptional.get();
    }

    @Override
    public Member getAuthenticatedMember() throws Exception {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            throw new UsernameNotFoundException("Not authroized.");
        }
        Object principal = authentication.getPrincipal();
        if (principal == null) {
            throw new Exception("You are not authorized");
        }
        Member authenticatedMember = (Member) principal;
        return authenticatedMember;
    }

}