package com.web.back.service;

public interface ManagementService {
}
