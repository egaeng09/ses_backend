package com.web.back.controller.management;

import com.web.back.service.LessonService;
import com.web.back.service.ManagementService;
import com.web.back.utils.ErrorResponseManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ManagementController {

    @Autowired
    private ErrorResponseManager errorResponseManager;

    @Autowired
    private ManagementService managementService;

}
