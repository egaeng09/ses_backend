package com.web.back.controller.account;

import java.util.Objects;

import com.web.back.dto.LoginDto;
import com.web.back.dto.MemberDto;
import com.web.back.dto.TokenDto;
import com.web.back.model.Member;
import com.web.back.security.JwtTokenProvider;
import com.web.back.utils.ErrorResponseManager;
import jakarta.servlet.http.HttpServletResponse;

import com.web.back.security.AuthenticationException;
import com.web.back.service.AccountService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
public class AccountController {
    @Value("${jwt.http.request.header}")
    private String tokenHeader;

    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private JwtTokenProvider jwtTokenProvider;
    @Autowired
    private AccountService accountService;
    @Autowired
    private ErrorResponseManager errorResponseManager;

    // 로그인
    @RequestMapping(value = "${jwt.get.token.url}", method = RequestMethod.POST)
    public ResponseEntity<?> login(@RequestBody LoginDto authenticationRequest,
            HttpServletResponse response) throws AuthenticationException {
        try {
            authenticate(authenticationRequest.getId(), authenticationRequest.getPassword());
            final UserDetails userDetails = accountService.loadUserByUsername(authenticationRequest.getId());
            final String token = jwtTokenProvider.generateToken(userDetails);
            MemberDto memberDto = accountService.convertUserToResponseDto((Member) userDetails);
            TokenDto tokenDto = new TokenDto();
            tokenDto.setToken(token);
            return new ResponseEntity<>(tokenDto, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(errorResponseManager.makeErrorResponse(e), HttpStatus.BAD_REQUEST);
        }
    }

    // 로그아웃
    @PostMapping("/logoutAccount")
    public ResponseEntity<?> logout(HttpServletResponse response) throws Exception {
        // 토큰 만료 시켜야 하나?
        return new ResponseEntity<>(HttpStatus.OK);
    }

    // 회원가입
    @PostMapping("/signup")
    public ResponseEntity<?> signUp(@RequestBody MemberDto memberDto) throws Exception {
        try {
            MemberDto signUpMemberDto = accountService.signUp(memberDto);
            return new ResponseEntity<>(signUpMemberDto, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(errorResponseManager.makeErrorResponse(e), HttpStatus.BAD_REQUEST);
        }
    }

    // 비밀번호 변경
    @PutMapping("/changePassword")
    public ResponseEntity<?> changePassword(@RequestBody MemberDto memberDto) throws Exception {
        try {
            MemberDto newMemberDto = accountService.changePassword(memberDto);
            return new ResponseEntity<>(newMemberDto, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(errorResponseManager.makeErrorResponse(e), HttpStatus.BAD_REQUEST);
        }
    }

    // 비밀번호 찾기
    @PostMapping("/findPassword")
    public ResponseEntity<?> findPassword(@RequestBody MemberDto memberDto) throws Exception {
        try {
            // 받아오도록
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(errorResponseManager.makeErrorResponse(e), HttpStatus.BAD_REQUEST);
        }
    }

    // 내 정보 조회
    @GetMapping("/my")
    public ResponseEntity<?> myPage(@RequestBody MemberDto memberDto) throws Exception {
        try {
            // 받아오도록
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(errorResponseManager.makeErrorResponse(e), HttpStatus.BAD_REQUEST);
        }
    }

//    // 회원 탈퇴
//    @PutMapping("/deleteAccount")
//    public ResponseEntity<?> deleteAccount(HttpServletResponse response) throws Exception {
//        try {
//            accountService.deleteAccount();
//            tokenCookieManager.deleteTokenFromCookie(response);
//            return new ResponseEntity<>(HttpStatus.OK);
//        } catch (Exception e) {
//            return new ResponseEntity<>(errorResponseManager.makeErrorResponse(e), HttpStatus.BAD_REQUEST);
//        }
//    }


    @ExceptionHandler({ AuthenticationException.class })
    public ResponseEntity<String> handleAuthenticationException(AuthenticationException e) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
    }

    // 키 인증 과정
    private void authenticate(String id, String password) {
        Objects.requireNonNull(id);
        Objects.requireNonNull(password);
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(id, password));
        } catch (BadCredentialsException e) {
            throw new AuthenticationException("ID 또는 비밀번호가 일치하지 않습니다.", e);
        } catch (DisabledException e) {
            throw new AuthenticationException("DISABLED MEMBER", e);
        }
    }
}